<!-- Source: sidebar.php -->
<?php dynamic_sidebar( 'blog' ); ?>