<?php
	// Include Libraries used in theme.
	include_once(TEMPLATEPATH . "/libraries/themesettings.php");
	include_once(TEMPLATEPATH . "/libraries/custom-post-types.php");
	include_once(TEMPLATEPATH . "/libraries/comments.php");
	include_once(TEMPLATEPATH . "/libraries/themesetup.php");
	include_once(TEMPLATEPATH . "/libraries/filters.php");
	include_once(TEMPLATEPATH . "/libraries/widgets.php");
	include_once(TEMPLATEPATH . "/libraries/shortcodes.php");
	include_once(TEMPLATEPATH . "/libraries/debug.php");
?>