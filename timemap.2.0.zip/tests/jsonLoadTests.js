function setUpPage() {
    jsonLoadTestSetup();
}