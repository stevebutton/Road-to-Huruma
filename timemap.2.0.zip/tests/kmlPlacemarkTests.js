function setUpPage() {
    kmlPlacemarkTestSetup();
}