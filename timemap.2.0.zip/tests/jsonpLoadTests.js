function setUpPage() {
    jsonpLoadTestSetup();
}