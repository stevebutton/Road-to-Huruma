function setUpPage() {
    kmlLoadTestSetup();
}