<?php
/*
   ================================================================
   MemberWing / RAP integration addon.
   by Gleb Esman, gleb@memberwing.com
   http://www.memberwing.com/
   ================================================================

   Copyright 2009 MemberWing. All Rights Reserved

   The sale, duplication or transfer of the script to any
   person other than the original purchaser is a violation
   of the purchase agreement and is strictly prohibited.

   By using this script you agree to the terms and conditions
   of use of the script.

*/

$g_query_addon_products__create =<<<QQQQ
CREATE TABLE IF NOT EXISTS `MW_addon_products` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `item_name` varchar(100) NOT NULL,
  `item_number` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
)
QQQQ;

$g_query_settings__create =<<<QQQQ
CREATE TABLE IF NOT EXISTS `MW_settings` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `key` varchar(32) NOT NULL,
  `value` varchar(512) NOT NULL,
  PRIMARY KEY  (`id`)
)
QQQQ;


$title="MemberWing addon";
$description="Integrates MemberWing - Wordpress membership site plugin with RAP";
$folders=explode("/",$_GET['path']);
$groupfolder=$folders[0];
$addonfolder=$folders[1];

?>
<td align=center>
   <table align=center cellpadding=3 cellspacing=0>
      <tr align=center><td colspan=2><h2>Installing <?php echo $title; ?></h2></td></tr>
      <?php
         /* Create any additional tables needed in the mySQL database for this Addon */
         @mysql_query($g_query_addon_products__create);
      ?>
      <tr align=center>
         <td align=right><div align="center">
            <img src="tick.jpg" width="15" height="15" /></div></td>
         <td align=left nowrap="nowrap">
            <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?php echo $title; ?> - supported products table added</font></td>
      </tr>
      <?php
         @mysql_query($g_query_settings__create);
      ?>
      <tr align=center>
         <td align=right><div align="center">
            <img src="tick.jpg" width="15" height="15" /></div></td>
         <td align=left nowrap="nowrap">
            <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?php echo $title; ?> - settings table added</font></td>
      </tr>
      <?php
         /* ____________ Define AddOn Module to Rapid Action Profits _________________ */

         $sql="SELECT id FROM addons
            WHERE title='$title'";
         $addres=@mysql_query($sql);
         $addrec=@mysql_fetch_assoc($addres);

         if ($addrec[id]=="")
         {
            $sql="INSERT INTO addons (title, description, groupfolder, addonfolder)
               VALUES('".$title."','".$description."','".$groupfolder."','".$addonfolder."')";
            @mysql_query($sql);
            $id=@mysql_insert_id();
         }

         /*_________________________________________________________________________*/

      ?>
      <tr align=center>
         <td align=right><div align="center">
            <img src="tick.jpg" width="15" height="15" /></div></td>
         <td align=left nowrap="nowrap">
            <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?=$title?> Installed!</font></td>
      </tr>
      <form method=post action="<?php echo $_SERVER['PHP_SELF']; ?>?action=addon&id=<?php echo $id; ?>">
      <tr align=center>
         <td colspan=2 align=center>
            <input type=submit name="submit" id="submit" value="Go to <?php echo $title; ?> Admin">
         </td>
      </tr>
      </form>
   </table>
</td>