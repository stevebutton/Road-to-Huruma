<?php

/*
   ================================================================
   MemberWing / RAP integration addon.
   by Gleb Esman, gleb@memberwing.com
   http://www.memberwing.com/
   ================================================================

   Copyright 2009 MemberWing. All Rights Reserved

   The sale, duplication or transfer of the script to any
   person other than the original purchaser is a violation
   of the purchase agreement and is strictly prohibited.

   By using this script you agree to the terms and conditions
   of use of the script.

*/

   // Item was just sold.
   // Make sure this item is in our list of interest and pass processing to MemberWing's notify_rap.php

   //---------------------------------------
   // Get list of all products of interest into associative array.
   // Get address of file to call
   $GEMW_products_assoc   = array();
   $GEMW_result = @mysql_query ("SELECT * FROM `MW_addon_products`");
   while ($GEMW_row = @mysql_fetch_assoc ($GEMW_result))
      {
      $GEMW_products_assoc[$GEMW_row['item_number']] = $GEMW_row['item_name'];
      }
   mysql_free_result ($GEMW_result);

   // Get current integration code
   $GEMW_result = @mysql_query ("SELECT * FROM `MW_settings` WHERE `key` = 'notify_rap_script'");
   if ($GEMW_row = @mysql_fetch_assoc ($GEMW_result))
      $GEMW_notify_rap_script = $GEMW_row['value'];
   else
      $GEMW_notify_rap_script = '';

   if (!$GEMW_notify_rap_script || !file_exists($GEMW_notify_rap_script))
      {
      exit ();
      }
   //---------------------------------------

   // Match Payal's IPN variable against list of products.
   if (array_key_exists ($_POST['item_number'], $GEMW_products_assoc) || in_array ($_POST['item_name'], $GEMW_products_assoc))
      {
      include_once ($GEMW_notify_rap_script);
      }
   else
      {
      }

/*
TODO:
   -  capture 'txn_id' username, pass, email inside notify_rap.php
   -  Store it somewhere inside 'MW_settings' table.
   -  Inside settings.php create tag - function MW_get_user_login(txn_id)
      This function will spit out HTML showing user login link, username, password - for convenience purposes.
   -  Inside download.html - include tag to show this info for new subscriber. <MW_get_user_login(txn_id);>
*/

?>
