<?php
/*
   ================================================================
   MemberWing / RAP integration addon.
   by Gleb Esman, gleb@memberwing.com
   http://www.memberwing.com/
   ================================================================

   Copyright 2009 MemberWing. All Rights Reserved

   The sale, duplication or transfer of the script to any
   person other than the original purchaser is a violation
   of the purchase agreement and is strictly prohibited.

   By using this script you agree to the terms and conditions
   of use of the script.

*/

// Debug code:
// http://localhost/wordpress/rap_admin/addons/RAP/memberwing_rap/admin.php?XDEBUG_SESSION_START=1

$GEMW_error_style = "border:2px solid red;padding:2px;background:#FFC;";

$GEMW_style1 = "";
$GEMW_initial_message = 'MemberWing addon settings';

//------------------------------------------
// Calculate URL of image
$GEMW_bytes_to_skip = strlen($_SERVER['SCRIPT_FILENAME']) - strlen($_SERVER['SCRIPT_NAME']) + 1;
$GEMW_base_dir_url = 'http://' . $_SERVER['HTTP_HOST'] . '/' . substr (dirname(__FILE__), $GEMW_bytes_to_skip);
$GEMW_base_dir_url = str_replace ('\\', '/', $GEMW_base_dir_url);
$GEMW_logo = $GEMW_base_dir_url . "/MemberWing_Avatar_75x52.gif";
$GEMW_seal = $GEMW_base_dir_url . "/seal.png";
//------------------------------------------

$GEMW_admin_table =<<<TTTT

<tr><td><!-- Apparently we are inside the table -->
<div align="center" style="margin:10px;padding:20px;border:1px solid gray;">
   <div>
   <img src="$GEMW_logo" /><br /><img src="$GEMW_seal" />
   <h2>__INITIAL_MESSAGE__</h2>
   </div>
   <form method='post' action='{$_SERVER['REQUEST_URI']}'>
      <table width="50%" border="0" cellspacing="0" cellpadding="2">
        <tr>
          <td colspan="2" style="border:1px solid gray;padding:5px;border-bottom:none;">
            <div align="center"><h3 style="padding:5px;border:1px solid #3C3;background:#DFD;">1. MemberWing + Rapid Action Profits Integration Code</h3></div>
            <div align="left">
               <ul>
                  <li>Login to MemberWing Admin Panel: (www.YOUR-SITE.com/wp-admin)</li>
                  <li>Go to Settings-&gt;MemberWing plugin-&gt;MemberWing + Rapid Action Profits Integration Code</li>
                  <li>Copy and paste this code here:</li>
               </ul>
            </div>
          </td>
        </tr>
        <tr>
          <td colspan="2" align="center" style="border:1px solid gray;padding:5px;border-top:none;border-bottom:none;padding-bottom:10px;">
            <div style="__STYLE1__">
               <input name="notify_rap_script" type="text" size="120" maxlength="512" value="__NOTIFY_RAP_SCRIPT__" />
            </div>
          </td>
        </tr>
        <tr>
          <td colspan="2" style="border:1px solid gray;padding:5px;border-top:none;">
            <div align="center">
               <h3 style="padding:5px;border:1px solid #3C3;background:#DFD;">2. Select product(s) to be integrated with MemberWing.</h3>
               Customer who purchased the product(s) selected below will automatically become a premium member of your portal.<br />
               Product name is used to determine his membership level. Use keywords: &quot;bronze&quot;, &quot;silver&quot;, &quot;gold&quot; or &quot;platinum&quot; in product name as a hint. If no keywords are used in product name - default level &quot;Gold&quot; will be assigned to new customer.
            </div>
          </td>
        </tr>
      __PRODUCT_ITEM_ROWS__
        <tr>
          <td colspan="2" style="border:1px solid gray;padding:5px;border-bottom:none;">
            <div align="center"><h3 style="padding:5px;border:1px solid #3C3;background:#DFD;">3. Press [Save Settings] and you're done!<h3></div>
          </td>
        </tr>
        <tr>
          <td colspan="2" style="border:1px solid gray;padding:5px;border-top:none;">
            <div align="center">
               <input type="submit" name="save_mw_settings" id="button" value="Save Settings" />
            </div>
          </td>
        </tr>
      </table>
   </form>
</div>
</td></tr>
TTTT;

$GEMW_admin_table_product_item_row =<<<TTTT
  <tr>
    <td align="center" width="6%" style="border:1px solid gray;padding:5px;"><input type="checkbox" name="product_items[]" value="__PRODUCT_ITEM_NUMBER__" __IS_CHECKED__ /></td>
    <td width="94%" style="border:1px solid gray;padding:5px;">__PRODUCT_ITEM_NAME__</td>
  </tr>
TTTT;


   //---------------------------------------
   // Get list of all existing products in 2 arrays - 1 numeric, another associative.
   $GEMW_products_num   = array();
   $GEMW_products_assoc = array();
   $GEMW_result = @mysql_query ("SELECT * FROM products");
   while ($GEMW_row = @mysql_fetch_assoc ($GEMW_result))
      {
      $GEMW_products_num[]   = array ('item_number'=>$GEMW_row['item_number'], 'item_name'=>$GEMW_row['item_name']);
      $GEMW_products_assoc[$GEMW_row['item_number']] = $GEMW_row['item_name'];

      if (!isset($GEMW_row['oto_flag']) || !$GEMW_row['oto_flag'])
         continue;

      $GEMW_products_num[]   = array ('item_number'=>$GEMW_row['oto_number'], 'item_name'=>$GEMW_row['oto_name']);
      $GEMW_products_assoc[$GEMW_row['item_number']] = $GEMW_row['oto_name'];
      }
   mysql_free_result ($GEMW_result);

   // Get current integration code
   $GEMW_result = @mysql_query ("SELECT * FROM `MW_settings` WHERE `key` = 'notify_rap_script'");
   if ($GEMW_row = @mysql_fetch_assoc ($GEMW_result))
      $GEMW_notify_rap_script = $GEMW_row['value'];
   else
      $GEMW_notify_rap_script = '';
   //---------------------------------------


   if (isset($_POST['save_mw_settings']))
      {
      // Save new entered settings.
      if (!isset($_POST['notify_rap_script']) || !trim($_POST['notify_rap_script']))
         {
         $GEMW_initial_message = "<div style='color:#F00;background:#FFC;'>MemberWing integration code field cannot be empty</div>";
         $GEMW_style1 = $GEMW_error_style;
         }
      else
         {
         if (!file_exists ($_POST['notify_rap_script']))
            {
            $GEMW_initial_message = "<div style='color:#F00;background:#FFC;'>Cannot find file: {$_POST['notify_rap_script']}<br/>Make sure you copied the correct code from MemberWing admin panel</div>";
            $GEMW_style1 = $GEMW_error_style;
            }
         else
            {
            // Inputs are valid. Save new settings in DBase (overwrite old ones).
            $GEMW_initial_message = "<div style='color:#060;background:#EFE;'>Settings are saved</div>";
            $GEMW_style1 = "";

            @mysql_query ('TRUNCATE TABLE `MW_addon_products`');
            @mysql_query ('TRUNCATE TABLE `MW_settings`');
            if (is_array($_POST['product_items']))
               {
               foreach ($_POST['product_items'] as $item_number)
                  {
                  @mysql_query ("INSERT INTO `MW_addon_products` (`item_name`, `item_number`) VALUES ('{$GEMW_products_assoc[$item_number]}', '$item_number')");
                  }

               $GEMW_notify_rap_script = trim ($_POST['notify_rap_script']);
               @mysql_query ("INSERT INTO `MW_settings` (`key`, `value`) VALUES ('notify_rap_script', '$GEMW_notify_rap_script')");
               }
            }
         }
      }

   //---------------------------------------
   // Display / re-display MW admin settings table.
   //
   // Get list of all products and construct admin table HTML

   $GEMW_product_rows = "";

   foreach ($GEMW_products_num as $product)
      {
      // Exists in out table?
      $GEMW_result = @mysql_query ("SELECT * FROM MW_addon_products WHERE item_number='{$product['item_number']}'");
      if (mysql_num_rows($GEMW_result) > 0)
         $GEMW_checked = 'checked="checked"';
      else
         $GEMW_checked = '';
      $GEMW_newrow = str_replace (array ('__PRODUCT_ITEM_NUMBER__', '__PRODUCT_ITEM_NAME__', '__IS_CHECKED__'), array ($product['item_number'], $product['item_name'], $GEMW_checked), $GEMW_admin_table_product_item_row);
      $GEMW_product_rows .= $GEMW_newrow;
      }

   $GEMW_admin_table = str_replace (array('__PRODUCT_ITEM_ROWS__','__STYLE1__','__INITIAL_MESSAGE__', '__NOTIFY_RAP_SCRIPT__'), array($GEMW_product_rows,$GEMW_style1,$GEMW_initial_message,$GEMW_notify_rap_script), $GEMW_admin_table);

   echo $GEMW_admin_table;
   //---------------------------------------

?>