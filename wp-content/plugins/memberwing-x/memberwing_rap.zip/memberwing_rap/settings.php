<?php

/*
   ================================================================
   MemberWing / RAP integration addon.
   by Gleb Esman, gleb@memberwing.com
   http://www.memberwing.com/
   ================================================================

   Copyright 2009 MemberWing. All Rights Reserved

   The sale, duplication or transfer of the script to any
   person other than the original purchaser is a violation
   of the purchase agreement and is strictly prohibited.

   By using this script you agree to the terms and conditions
   of use of the script.

*/


/*
functions-tags to be used in HTML pages will be added here.
*/

?>