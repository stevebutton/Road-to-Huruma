<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>

	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	
	<title><?php
		if ( is_front_page() ) {
		} elseif ( is_category() ) {
			_e( 'Category: ', LANGUAGE ); wp_title( '' ); echo ' - ';
		} elseif ( function_exists( 'is_tag' ) && is_tag() ) {
			single_tag_title( __( 'Tag Archive for &quot;', LANGUAGE ) ); echo '&quot; - ';
		} elseif ( is_archive() ) {
			wp_title( '' ); _e( ' Archive - ', LANGUAGE );
		} elseif ( is_page() ) {
			echo wp_title( '' ); echo ' - ';
		} elseif ( is_search() ) {
			_e( 'Search for &quot;', LANGUAGE ); echo esc_html( $s ) . '&quot; - ';
		} elseif ( ! ( is_404() ) && ( is_single() ) || ( is_page() ) ) {
			wp_title( '' ) ; echo ' - ';
		} elseif ( is_404() ) {
			_e( 'Not Found - ', LANGUAGE );
		} bloginfo( 'name' );
	 ?></title>
	 
	 <?php require( CELTA_LIB . "theme-options-vars.php" ); ?>
	 
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_url' ); ?>" media="screen" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/presentation/<?php echo str_replace( ' ', '', strtolower( $celta_skin ) ); ?>.css" type="text/css" media="screen" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<link rel="shortcut icon" href="<?php echo $celta_favicon; ?>" />
	
	<?php wp_head(); ?>
	
	<?php if ( is_single() ) { ?>
		<script type="text/javascript">
			jQuery(document).ready( function() {
				jQuery('#navigation a').each( function() {
					var hash = jQuery(this).attr('href');
					jQuery(this).attr('href', '<?php echo home_url(); ?>'+'/'+hash);
				});
			})
		</script>
	<?php } ?>
	
	<style>
		<?php if ( $celta_custom_css != '' ) { echo stripslashes( $celta_custom_css ); } ?>
	</style>
	
</head>

<body <?php body_class(); ?>>