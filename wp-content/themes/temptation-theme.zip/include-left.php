<?php require( CELTA_LIB . "theme-options-vars.php" ); ?>

<div id="left" class="<?php echo strtolower( str_replace( ' ', '-', $celta_pattern_left ) ); ?>">
	<ul id="navigation">
		<?php 
			$pages = get_pages( 'sort_order=asc&sort_column=menu_order&depth=1' );
			foreach ( $pages as $pag ) {
				$new_title = str_replace( " ", "", strtolower( $pag->post_name ) );
				echo '<li><a href="#' . $new_title . '" title="' . $pag->post_title . '">' . $pag->post_title . '</a></li>';
			}
		?>
	</ul>

	<div id="logo">
		<h1>
			<a href="#home">
				<?php if ( $celta_logo != '' ) { ?>
					<img src="<?php echo $celta_logo; ?>" alt="" />
				<?php } else { ?>
					<?php bloginfo( 'name' ); ?>
				<?php } ?>
			</a>
		</h1>
		<p><?php bloginfo( 'description' ); ?></p>
	</div>	
	<p id="copyright"><?php echo $celta_copyright; ?></p>
</div><!-- end left -->	